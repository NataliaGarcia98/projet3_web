
const fileHandler = require('./FileHandler');
/* class Router{
    constructor(){
        //is this a const, How do you lock in a class attribute in JS
        this.http = require("http");
        this.fs = require('fs');
        this.server;
        this.data;
    } */

    /* recieveHtmlFile(buttonId){ */
    //const server = http.createServer
    function routeRequest(requestListener, res)
        {
            let htmlText;
            //let repImages = /\/images/;
            if (requestListener.url === "/") {
                console.log(__dirname); 
                res.write("<h1>Racine</h1>");
                res.end();
             
            }else if(requestListener.url === "/Accueil"){
               // res.write("<h1>Route Accueil</h1>");
                htmlText = fileHandler.sendContent(requestListener.url)
                console.log("DB_15" + htmlText);
                res.end();

            } else if(requestListener.url === "/Fabrication"){
                res.write("<h1>Route Fabrication</h1>");
                res.end();

            }else if(requestListener.url === "/Impact"){
                res.write("<h1>Route Impact</h1>");
                res.end();

            }else if(requestListener.url === "/Solution"){
                res.write("<h1>Route Solution</h1>");
                res.end();

            }else if(requestListener.url === "/Utilisation"){
                res.write("<h1>Route Utilisateur</h1>");
                res.end();
            }else{
                res.write("<h1>Route introuvable. </h1>");
                res.end();
            }
        }
        //server.listen(4200);



            /*else if (repImages.test(req.url)) {
                //let nomFichier = "." + req.url;
                //let contentType = 'image/jpg';
                //let fichier = fs.readFileSync(nomFichier);
                //requestListener.writeHead(200, {'Content-Type': contentType });
                //requestListener.end(fichier, 'binary');
            }
            else if (req.url === "/route2") {
                //requestListener.write("<h1>Route 2</h1>");
                //requestListener.end();
            }
            else {
                requestListener.write("<p>Erreur: Cette page n'existe pas</p>");
                requestListener.end();
            }
            });
            server.listen(4200);*/
    

/* } 
*/


//module.exports.log = function
module.exports = { routeRequest };




/*
    function routeRequest(requestListener, res){
        const requestedPath = "" + requestListener.url;
        console.log(requestedPath);
            //let repImages = /\/images/;
            if (requestedPath.startsWith('/')) {
                console.log(__dirname); 
                res.write("<h1>Racine</h1>");
                res.end();
                //${buttonId}
                //path.join(path.dirname + "/html/Fabrication.html");
                //let url = "E:\rebec\session_4\prog_JavaScript\projet_3\projet3_workspace\html\Acceuil.html";
              
                /*fs.readFile(path.join(path.dirname + "/html/"), "utf8",
                (err, data) => {
                    if (err) {
                        throw "C'est l'heure d'une pause! " + err;
                        return err;
                    }
                    console.log("success");
                    res.write("<h1>Route 2</h1>");
                    res.end;
                    //requestListener.writeHead(200, { 'Content-Type': 'text/html' });
                    //this.data = requestListener.write(data);
                    //return data;
                    //requestListener.end();
                });
            }else if(requestedPath.startsWith("/Accueil")){
                res.write("<h1>Route Accueil</h1>");
                res.end();

            } else if(requestedPath.startsWith("/Fabrication")){
                res.write("<h1>Route Fabrication</h1>");
                res.end();

            }else if(requestedPath.startsWith("/Impact")){
                res.write("<h1>Route Impact</h1>");
                res.end();

            }else if(requestedPath.startsWith("/Solution") ){
                res.write("<h1>Route Solution</h1>");
                res.end();

            }else if(requestedPath.startsWith("/Utilisation") ){
                res.write("<h1>Route Utilisateur</h1>");
                res.end();
            }else{
                res.write("<h1>Route introuvable. </h1>");
                res.end();
            }
        }

*/

