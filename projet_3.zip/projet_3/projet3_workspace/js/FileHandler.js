const http = require("http");
const fs = require('fs');
const path = require('path');


function sendContent(url){
    let urlSplit = url.split('/');
    let pathName;
    let htmlPageName; //= urlSplit[1];
    if(cheminTab.length > 1){
        htmlPageName = urlSplit[1];
        pathName = path.join(path.dirname + `/${htmlPageName}`);
        console.log("DB_87" + pathName);

        //return htmlPageName;
        //res.write(`<p>Le nom du fichier est ${cheminTab[2]}</p>`);
    }
        
       //${buttonId}
                //path.join(path.dirname + "/html/Fabrication.html");
                //let url = "E:\rebec\session_4\prog_JavaScript\projet_3\projet3_workspace\html\Acceuil.html";
              
                /*fs.readFile(path.join(path.dirname + "/html/"), "utf8",
                (err, data) => {
                    if (err) {
                        throw "C'est l'heure d'une pause! " + err;
                        return err;
                    }
                    console.log("success");
                    res.write("<h1>Route 2</h1>");
                    res.end;
                    //requestListener.writeHead(200, { 'Content-Type': 'text/html' });
                    //this.data = requestListener.write(data);
                    //return data;
                    //requestListener.end();
                });*/
}

function sendCss(url){
    
}


function sendImage(url){
    
}


module.exports = 
{
    sendContent,
    sendCss, 
    sendImage
};
