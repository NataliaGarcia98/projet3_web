

window.onload = function () {
    const menu = new Menu();
    menu.startFunction();
}

class Menu{

    constructor(){
        //this.url;
        this.buttonID;
        this.MenuDiv = document.getElementById("menu");
    }
    

    startFunction(){
        this.obtenirMeteo();
    }

    obtenirMeteo() {
        //document.getElementById("meteo").innerHTML = ""
        let api_key = '568628788222f8da10914685f8dfbdac';
        let url = 'http://api.openweathermap.org/data/2.5/weather?q=Montreal,ca&units=metric&appid=' + api_key;
        fetch(url)
            .then((reponse) => reponse.json())
            .then((data) => {
                this.afficheMeteo(data);
                console.log(meteoData)
                //const meteoSnippet = meteoData.getDOMElement()
                //document.getElementById("meteo").appendChild(meteoSnippet);
            })
        //this.vue.afficheListeRecettes()
    }



    afficheMeteo(responseOpenWeatherMap) {
        const meteo = responseOpenWeatherMap
        //console.log(responseOpenWeatherMap)
        let temperature= meteo.main.temp;
        let ressentie = meteo.main.feels_like;
        let ville = meteo.name;
        let date = new Date();

        // Icon
        const iconCode = meteo.weather[0].icon;
        let url = `http://openweathermap.org/img/wn/${iconCode}@2x.png`;
        ///this.url = this.getIconImage(iconCode)

        ///////////////////////////////////////////////

        //const elt = document.createElement("div")
        const elt = document.getElementById("meteo_div");
        elt.classList = "meteoSnippet";
        const tempPara = document.createElement("p");
        tempPara.innerHTML = "Temperature: " + temperature+ "C<br>Ressentie: " + ressentie + " C";

        const namePara = document.createElement("p");
        namePara.innerHTML = ville;

        // if( this.url === undefined) {
        //     this.url = this.getIconImage(this.iconCode)
        // }
        const img = document.createElement("img");
        img.src = url;

        elt.appendChild(namePara);
        elt.appendChild(img);
        elt.appendChild(tempPara);

        //return elt;
    }



    recieveClickedButton(){
        MenuDiv.addEventListener("click", )
    }

    //document.addEventListener("DOMContentLoaded", function () {})
}
